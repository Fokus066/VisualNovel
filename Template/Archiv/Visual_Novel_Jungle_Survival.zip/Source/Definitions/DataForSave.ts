namespace Template {
      
  export let dataForSave = {
    nameProtagonist: "",
    energy: 100,
    fitnessUncle: false,
    //scorefishing: 0,
    item_lighter: false,
    no_water: false,
    item_acaiberry: false,
    item_fish:false,
    item_spear: false,
    item_liane: false,
    item_axe: false,
    number_branch: 0,
    number_stone: 0,
    item_suitcase: false,
    open_suitcase: false,
    uncle_alive: true,
    mission: 1
  };

}