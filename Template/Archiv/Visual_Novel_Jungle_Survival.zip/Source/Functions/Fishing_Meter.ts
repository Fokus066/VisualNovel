namespace Template {
    export async function Fishing_Meter(): ƒS.SceneReturn {
        // console.log("Text");

        // await ƒS.Location.show(locations.fishing_area);
        // await ƒS.update(transitions.goslow.duration, transitions.goslow.alpha, transitions.goslow.edge);
        // await ƒS.update(1);
        // await ƒS.Speech.tell(characters.narrator, " ", true);


        // document.getElementsByName("scoreRyu").forEach(meterStuff => meterStuff.hidden = true);
        // document.getElementsByName("scoreForRyu").forEach(meterStuff => meterStuff.hidden = true);
        // dataForSave.scorefishing += 10;

        
        // // let fishing = {
        //     push: "",
        // }
  

        // ƒS.Speech.hide();
        //await ƒS.Location.show(locations.fishing_area);
        //await ƒS.Character.show(characters.Ryu, characters.Ryu.pose.normal, ƒS.positionPercent(30, 100));
        //await ƒS.update(1);
        //ƒS.Speech.show();
        //document.getElementsByName("scoreRyu").forEach(meterStuff => meterStuff.hidden = false);
        //document.getElementsByName("scoreForRyu").forEach(meterStuff => meterStuff.hidden = false);


        //dataForSave.scorefishing = "You earned 50 points on Ryus bar",
        // dataForSave.scoreAoi += 15;
        // dataForSave.scoreForAoi = "You earned 15 points on Aois bar",



        //await ƒS.update(1);
        //await ƒS.Speech.tell(characters.Ryu, text.Ryu.T0001);
        // document.getElementById("meterli").hidden = true;
        // document.getElementById("meterInput").hidden = true;
        // beide auf einmal hiden
        // document.getElementsByName("a").forEach(meterStuff => meterStuff.hidden = true);
        //await ƒS.Character.hide(characters.Ryu);


        // dataForSave.state.scoreAoi += 100;










    }




}