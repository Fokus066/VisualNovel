namespace Template {
    export async function End(): ƒS.SceneReturn {

        ƒS.Text.print("<p>Das Spiel ist hier zu Ende.");
        await ƒS.Speech.tell(null, null, true);
        await ƒS.update(4);
    }

}
